package com.intive.SearchBoxPro;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;



public class BaseSearchBox {
	
public WebDriver driver;
	
	public WebDriver initializeDriver() throws IOException {
		
		Properties prop = new Properties();
		FileInputStream fis = new FileInputStream("C:\\Users\\Sanjeeva\\eclipse-workspace\\SearchBoxPro\\src\\main\\java\\com\\intive\\SearchBoxPro\\data.properties");
		prop.load(fis);//Loads the property file which contains the browser name
		String browser = prop.getProperty("browser");// Reads browser name from property file.
		
		if(browser.equals("chrome")) {
			
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\Sanjeeva\\Desktop\\Driver\\chromedriver.exe");
			driver = new ChromeDriver();
			
		
		}
		else if(browser.equals("firefox")) {
			System.setProperty("webdriver.gecko.driver", "C:\\Users\\Sanjeeva\\Desktop\\Driver\\geckodriver.exe");
			driver = new FirefoxDriver();
			
		}
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);//Implicit wait to synchronize browser with test scripts
		return driver;
	}

}
