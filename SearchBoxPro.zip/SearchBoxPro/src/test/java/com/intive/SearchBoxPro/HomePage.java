package com.intive.SearchBoxPro;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pageObjects.CheckOutPage;
import pageObjects.LandingPage;

public class HomePage extends BaseSearchBox {

	@BeforeTest //This method would launch the browser and amezon.com site.
	public void beforeTest() throws IOException {
		driver = initializeDriver();
		driver.manage().window().maximize();
		driver.get("http://www.amezon.com");

	}

	@Test // This method contains actual test case
	public void basePageNavi() throws IOException, InterruptedException {

		LandingPage landP = new LandingPage(driver);

		landP.enterText().sendKeys("Twix");
		clickAddCart(landP);
		landP.enterText().sendKeys("Snickers");
		clickAddCart(landP);
		landP.enterText().sendKeys("Skittles");
		clickAddCart(landP);

		CheckOutPage ObjCheckOut = new CheckOutPage(driver);
		ObjCheckOut.checkOut().click();
	}

	@AfterTest 
	public void afterTest() {
		driver.close();//closes the window after test script execution.

	}
	//This method would test sort  and add to cart functionality.
	public void clickAddCart(LandingPage lPage) {
		WebDriverWait wait = new WebDriverWait(driver, 20);
		lPage.clickButton().click();
		lPage.clickSortDropDown().selectByIndex(1);

		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='submit.addToCart']")));

		scrollDown();
		lPage.addCart().click();

	}
	//This method uses JavaScriptExecutor to scroll the window down.
	public void scrollDown() {
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("window.scrollBy(0,500)", "");
	}

}// end of class
