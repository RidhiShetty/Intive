package pageObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class CheckOutPage {

	public WebDriver driver;

	public CheckOutPage(WebDriver driver2) {

		this.driver = driver2;
	}

	// This method finds web-locator to checkout button
	public WebElement checkOut() {

		List<WebElement> webCheckout = driver
				.findElements(By.xpath("//div[@class='a-row'] //span[@class='a-button-inner']"));
		return webCheckout.get(1);

	}

}
