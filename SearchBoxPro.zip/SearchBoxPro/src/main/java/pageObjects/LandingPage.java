package pageObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class LandingPage {

	public WebDriver driver;

	/*
	 * In order to support Page Object model, Page Factory is implemented
	 * using @Findby annotation. In this code, Page Factory is used to initialize
	 * web elements that are defined in web page classes. PageFactory.initElements
	 * eliminates the StaleElementReferenceException.
	 */

	@FindBy(xpath = "//*[@id='twotabsearchtextbox']")
	WebElement searchBox;

	@FindBy(xpath = "//input[@value='Go']")
	WebElement searchButton;

	@FindBy(xpath = "//*[@name='sort']")
	WebElement sortDropDown;

	@FindBy(xpath = "//input[@name='submit.addToCart']")
	List<WebElement> addCart;

	public LandingPage(WebDriver driver2) {

		this.driver = driver2;
		PageFactory.initElements(driver, this);
	}

	public WebElement enterText() {
		return searchBox;

	}

	public WebElement clickButton() {
		return searchButton;

	}

	public Select clickSortDropDown() {
		Select dropdown = new Select(sortDropDown);
		return dropdown;

	}

	public WebElement addCart() {
		List<WebElement> listOfElements = addCart;
		return listOfElements.get(0);

	}

}
